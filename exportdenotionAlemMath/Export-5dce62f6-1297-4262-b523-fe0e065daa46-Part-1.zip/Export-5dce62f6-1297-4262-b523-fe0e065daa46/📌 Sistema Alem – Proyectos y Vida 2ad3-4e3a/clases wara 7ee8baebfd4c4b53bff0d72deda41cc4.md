# clases wara

PAGOS MENSUALES

[https://www.notion.so](https://www.notion.so)

[PAGOS MENSUALES](clases%20wara/PAGOS%20MENSUALES%2013239d3511ca808e9263ddad3730ab09.csv)