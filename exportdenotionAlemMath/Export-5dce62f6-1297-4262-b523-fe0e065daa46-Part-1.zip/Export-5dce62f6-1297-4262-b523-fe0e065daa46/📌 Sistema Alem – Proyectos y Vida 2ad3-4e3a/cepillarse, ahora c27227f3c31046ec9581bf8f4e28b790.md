# cepillarse, ahora

Quickly create a rich document.

# Jot down some text

---

They found Mary, as usual, deep in the study of thorough-bass and human nature; and had some extracts to admire, and some new observations of threadbare morality to listen to. Catherine and Lydia had information for them of a different sort.

# Make a to-do list

---

- [ ]  Wake up
- [ ]  Eat breakfast
- [x]  Brush teeth

# Create sub-pages

---

[Sub Page](cepillarse,%20ahora/Sub%20Page%20c4eb86cb7251485dab026f499e036d31.md)

# Embed links

---

[Beyond Frank Lloyd Wright: A Broader View of Art in Chicago](https://www.nytimes.com/2018/03/08/arts/chicago-museums-art.html?rref=collection%2Fsectioncollection%2Ftravel)

[Havana's Symphony of Sound](https://www.nytimes.com/2018/03/12/travel/havana-cuba.html?rref=collection%2Fsectioncollection%2Ftravel)

[Clase Briseyda ](cepillarse,%20ahora/Clase%20Briseyda%209e3b0230a8de4cc4b3b8a85edacd1e3c.md)