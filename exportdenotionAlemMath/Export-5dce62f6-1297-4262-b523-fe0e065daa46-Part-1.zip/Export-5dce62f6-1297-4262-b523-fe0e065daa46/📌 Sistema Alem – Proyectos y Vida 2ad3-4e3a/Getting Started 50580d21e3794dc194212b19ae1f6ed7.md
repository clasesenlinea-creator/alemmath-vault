# Getting Started

👋 Welcome to Notion!

Here are the basics:

- [ ]  Click anywhere and just start typing
- [ ]  Hit `/` to see all the types of content you can add - headers, videos, sub pages, etc.
    
    [Example sub page](Getting%20Started/Example%20sub%20page%20779b287b52bc428d88406d9f54ca60c0.md)
    
- [ ]  Highlight any text, and use the menu that pops up to **style** *your* ~~writing~~ `however` [you](https://www.notion.so/product) like
- [ ]  See the `⋮⋮` to the left of this checkbox on hover? Click and drag to move this line
- [ ]  Click the `+ New Page` button at the bottom of your sidebar to add a new page
- [ ]  Click `Templates` in your sidebar to get started with pre-built pages
- This is a toggle block. Click the little triangle to see more useful tips!
    - [Template Gallery](https://www.notion.so/181e961aeb5c4ee6915307c0dfd5156d?pvs=21): More templates built by the Notion community
    - [Help & Support](https://www.notion.so/e040febf70a94950b8620e6f00005004?pvs=21): ****Guides and FAQs for everything in Notion
    - Stay organized with your sidebar and nested pages:
        
        ![](Getting%20Started/infinitehierarchynodither.gif)
        
    

See it in action:

[1 minute](https://youtu.be/TL_N2pmh9O0)

1 minute

[4 minutes](https://youtu.be/FXIrojSK3Jo)

4 minutes

[2 minutes](https://youtu.be/2Pwzff-uffU)

2 minutes

[2 minutes](https://youtu.be/O8qdvSxDYNY)

2 minutes

Visit our [YouTube channel](http://youtube.com/c/notion) to watch 50+ more tutorials

👉**Have a question?** Click the `?` at the bottom right for more guides, or to send us a message.