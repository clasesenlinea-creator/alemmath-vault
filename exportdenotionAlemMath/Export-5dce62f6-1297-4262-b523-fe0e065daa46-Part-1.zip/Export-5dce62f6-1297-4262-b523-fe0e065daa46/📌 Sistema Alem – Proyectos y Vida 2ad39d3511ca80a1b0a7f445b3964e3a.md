# 📌 Sistema Alem – Proyectos y Vida

<aside>
💡

ACCESOS RAPIDOS — Ve directamente a lo que necesitas:

✅ Tareas del dia: [](DIARIO%20TAREAS%2012a39d3511ca8070beaacaa6e2e905fb.md) 

📅 Rutina diaria: [RUTINA DE HOY](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/REGISTRO%20DIARIO/RUTINA%20DE%20HOY%202e239d3511ca80bab00cd0e1d4134933.md) 

📓 Registro diario: [](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/REGISTRO%20DIARIO%202e239d3511ca80a7a96af83df0fa081d.csv) 

💰 Gastos del dia: [GASTOS DE HOY DIA](DIARIO%20TAREAS/GASTOS%20DE%20HOY%20DIA%202e339d3511ca804d8d7ac49c462a02ee.md) 

</aside>

---

## 🗂️ Bases de Datos y Estructura

Base de datos: **ÁREAS**

| **Nombre del área** | **Tipo (Profesional / Personal / Hábito)** | **Notas** |
| --- | --- | --- |
| Matemáticas/AlemMath | Profesional |  |
| Ingles | Profesional |  |
| Programacion | Personal |  |
| Gastronomia | Personal |  |
| Musica | Personal |  |
| Salud | Habito |  |
| Negocios | Profesional |  |

4.2. Base de datos: **PROYECTOS**

| Nombre  | Area | Prioridad | Horizonte | Estado | Siguiente accion clave |
| --- | --- | --- | --- | --- | --- |
|  | (relacional a la tabla ÁREAS) | (Alta / Media / Baja) | (0–12 meses / 1–3 años / 3–7+ años) | (En curso / En pausa / Idea / Completado) | (texto corto, algo que puedas hacer esta semana) |
| Terminar carrera de matemáticas | Matemáticas/AlemMath | ALTA | 1–3 años | EN CURSO | Completar materias del semestre |
| Sistema de enseñanza AlemMath 1.0 | Matemáticas/AlemMath | ALTA | 0–12 meses | EN CURSO |  |
| Curso pregrabado de Teoría de Números – Nivel inicial | Matemáticas/AlemMath | ALTA | 0–12 meses | EN PAUSA |  |
| Curso pregrabado de Geometría Primaria | Matemáticas/AlemMath | ALTA | 0–12 meses | EN PAUSA |  |
| Inglés para enseñar online | Ingles | MEDIA | 1–3 años | EN PAUSA |  |
| Aprender programación (Python) | Programacion | MEDIA | 1–3 años | IDEA |  |
| Ordenar recetas del restaurante de mi mamá | Gastronomia | MEDIA | 1–3 años | IDEA |  |
| Crecer restaurante de mamá | Gastronomia | MEDIA | 1–3 años | IDEA |  |
| Proyecto hamburguesería propia (incubadora) | Negocios | BAJA | 3–7+ años | IDEA |  |
| Banda y ensayos | Musica | ALTA | 0–12 meses | EN PAUSA |  |
|  |  |  |  |  |  |

Base de datos: **TAREAS**

| Nombre de la tarea | Proyecto al que pertenece | Fecha límite / estimada | Estado |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |

[Calendario y horarios](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/Calendario%20y%20horarios%202ad39d3511ca80a4a3e4c493796dfce5.csv)

## 📝 Operaciones Diarias

| TAREAS | OBSERVACIONES | DESIGNADO |
| --- | --- | --- |
| CUESTIONARIO 6TO PRIM | preg 15 es ambiguo, porque hay piramides de base cuadrada
preg 18 no dar pista, es 6to prim
preg 21 ambiguo
preg 25 la respuesta es obvia
preg 50 la respuesta esta mal | YUREM |
|  |  |  |

[BETA 2.1](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/BETA%202%201%202e039d3511ca8039b9f5f39d58c9299b.md)

[REGISTRO DIARIO](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/REGISTRO%20DIARIO%202e239d3511ca80a7a96af83df0fa081d.csv)

[clases wara](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/clases%20wara%207ee8baebfd4c4b53bff0d72deda41cc4.md)

## 📂 Subpáginas y Espacios de Trabajo

[TRABAJOACTUAL2025](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/TRABAJOACTUAL2025%202a939d3511ca804b8c8cf02250f7b39c.csv)

[TRABAJO2025](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/TRABAJO2025%202a939d3511ca8055934be63925a58f2e.csv)

[OFICINA TAREAS](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/OFICINA%20TAREAS%2012a39d3511ca80dcbde5e7e43ee86154.csv)

[clases wara](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/clases%20wara%2014a39d3511ca80be8441d8074aa9f5d4.csv)

[cepillarse, ahora](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/cepillarse,%20ahora%20c27227f3c31046ec9581bf8f4e28b790.md)

[PROYECTO CHINA](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/PROYECTO%20CHINA%2012a39d3511ca80f689c3eeaa50ff6567.csv)

[UMSS TAREAS](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/UMSS%20TAREAS%2012a39d3511ca8093993ff34f07d46471.csv)

[UNDERJAZZ TAREAS](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/UNDERJAZZ%20TAREAS%2012a39d3511ca804e958fdc5a44376926.csv)

[SAN AGUSTIN TAREAS](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/SAN%20AGUSTIN%20TAREAS%2012a39d3511ca80b3a557de25b08e270d.csv)

[GENERAL TAREAS](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/GENERAL%20TAREAS%2012a39d3511ca80278478fc03ccaf6079.csv)

[GRUPO LMV 1530](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/GRUPO%20LMV%201530%2012d39d3511ca80099f11f1825b41d605.csv)

[Journal](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/Journal%20cb4bd1b49b9148e7877de8f556f91608.csv)

[Reading List](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/Reading%20List%20e6b7f6656928450b927ea68e029afa0e.md)

[Personal Home](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/Personal%20Home%20fc191468492449d6846b447dfa836b33.md)

[Getting Started](%F0%9F%93%8C%20Sistema%20Alem%20%E2%80%93%20Proyectos%20y%20Vida%202ad3-4e3a/Getting%20Started%2050580d21e3794dc194212b19ae1f6ed7.md)